# Kosh Market Flows — Fix Handoff

This is an audit/remediation handoff based on the uploaded Grok workspace ZIP. It is not a claim that the source project has been patched, built, or deployed.

Included:
- `Kosh_Market_Flows_Audit_and_Fix_Prompt.md`: exact findings against the current source files and a full implementation specification.

Key verified code findings:
- Daily flows are currently merged from a Strota CSV and a GitHub JSON history.
- The server reports ~172 sessions and says the NSE source is blocked from the server.
- Nifty history is fetched from Yahoo starting at the first flow date, causing index coverage to be artificially truncated too.
- Chart line is currently rebased to 100, not actual Nifty close.
- API AI prompt gets limited facts and only returns a plain-text note.
- Analogue distance only uses FII, DII, and index return.
- Market Overview already renders `<MarketFlowsGlance />` after the Winners and Losers tables; preserve this placement.
- Current official NSE category is labelled FII/FPI; changing visible label to FII must not conceal the underlying definition.

Do not use this handoff to claim that 10–20 years of flow data are already available. That requires a verified backfill source and data-rights review.
