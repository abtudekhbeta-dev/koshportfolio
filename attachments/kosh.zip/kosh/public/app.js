import {
  buildMixPath,
  sliceNav,
  toIndexed,
  withDrawdown,
  windowReturn,
  ytdReturn,
  mixCagr,
  riskMetrics,
  monthBuckets,
  weekBuckets,
  rollingSeries,
  fmtInr,
  fmtPct,
  dash,
  saneDayPnl,
  sectorOf,
  baseSym,
  insights,
  SECTOR_BENCH,
  capOf,
  holdingWindows,
  sectorSleeve,
  pathFromBars,
} from "./engine.js";

const BENCH = {
  nifty: { symbol: "^NSEI", name: "Nifty 50" },
  sensex: { symbol: "^BSESN", name: "Sensex" },
  bank: { symbol: "^NSEBANK", name: "Bank Nifty" },
  it: { symbol: "^CNXIT", name: "Nifty IT" },
  pharma: { symbol: "^CNXPHARMA", name: "Nifty Pharma" },
  mid: { symbol: "^NSEMDCP50", name: "Nifty Midcap 50" },
  n500: { symbol: "^CRSLDX", name: "Nifty 500" },
  n100: { symbol: "^CNX100", name: "Nifty 100" },
};

const SAMPLE = [
  { symbol: "RELIANCE", name: "Reliance", qty: 20, avg: 1240 },
  { symbol: "TCS", name: "TCS", qty: 8, avg: 3600 },
  { symbol: "HDFCBANK", name: "HDFC Bank", qty: 25, avg: 1480 },
  { symbol: "INFY", name: "Infosys", qty: 15, avg: 1450 },
  { symbol: "BHARTIARTL", name: "Bharti", qty: 30, avg: 1450 },
  { symbol: "ITC", name: "ITC", qty: 80, avg: 420 },
  { symbol: "LT", name: "L&T", qty: 6, avg: 3400 },
  { symbol: "SUNPHARMA", name: "Sun Pharma", qty: 10, avg: 1650 },
];

const $ = (sel, el = document) => el.querySelector(sel);
const app = $("#app");
let tape = [];
let chartRef = null;

function uid() {
  return Math.random().toString(36).slice(2, 9);
}
function session() {
  try {
    return JSON.parse(localStorage.getItem("kosh_session") || "null");
  } catch {
    return null;
  }
}
function setSession(s) {
  localStorage.setItem("kosh_session", JSON.stringify(s));
}
function userKey() {
  const s = session();
  if (!s) return null;
  return s.guest ? "guest" : "u:" + s.user;
}
function loadPorts() {
  const k = userKey();
  if (!k) return [];
  try {
    return JSON.parse(localStorage.getItem("kosh_ports_" + k) || "[]");
  } catch {
    return [];
  }
}
function savePorts(p) {
  localStorage.setItem("kosh_ports_" + userKey(), JSON.stringify(p));
}
function users() {
  try {
    return JSON.parse(localStorage.getItem("kosh_users") || "[]");
  } catch {
    return [];
  }
}

function route() {
  const h = location.hash.replace(/^#/, "") || "/";
  const parts = h.split("/").filter(Boolean);
  return { path: "/" + parts.join("/"), parts };
}

window.addEventListener("hashchange", () => render());
window.addEventListener("resize", () => {});

async function api(path) {
  const r = await fetch(path);
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

async function loadTape() {
  try {
    const d = await api("/api/tape");
    tape = d.rows || [];
  } catch {
    tape = [];
  }
}

function topbar(extra = "") {
  const s = session();
  const who = !s ? "" : s.guest ? "Guest" : s.user;
  return `
    <header class="top">
      <a class="brand" href="#/">Kosh</a>
      <div class="tape">${tape
        .map(
          (t) =>
            `<span>${t.label} <b>${t.price ? t.price.toLocaleString("en-IN") : "—"}</b> <span class="${t.changePct >= 0 ? "up" : "dn"}">${t.changePct ? t.changePct.toFixed(2) + "%" : ""}</span></span>`,
        )
        .join("")}</div>
      <div class="navbtns">
        ${s ? `<a class="btn ghost" href="#/compare">Compare</a>` : ""}
        ${s ? `<button class="btn pri" id="addPort">+ Add</button>` : ""}
        ${s ? `<span class="chip">${who}</span><button class="btn ghost" id="out">Sign out</button>` : ""}
      </div>
    </header>
    ${extra}
  `;
}

function bindTop() {
  $("#out")?.addEventListener("click", () => {
    localStorage.removeItem("kosh_session");
    location.hash = "#/";
    render();
  });
  $("#addPort")?.addEventListener("click", () => showAddModal());
}

async function render() {
  const s = session();
  const r = route();
  if (!tape.length) await loadTape();
  if (!s && r.path !== "/") return authView();
  if (r.parts[0] === "p" && r.parts[1]) return portfolioView(r.parts[1]);
  if (r.parts[0] === "compare") return compareView();
  if (r.parts[0] === "s" && r.parts[1]) return stockView(r.parts[1]);
  return homeView();
}

function authView() {
  app.innerHTML = `
    ${topbar()}
    <section class="auth card">
      <h1>Kosh</h1>
      <p class="sub">Track Indian portfolios. Live prices. Mix path does not need buy dates.</p>
      <div class="grid" style="gap:10px">
        <button class="btn pri" id="guest">Continue as guest</button>
        <div class="hint">No details. Local to this browser.</div>
        <hr style="border:0;border-top:1px solid var(--line);margin:6px 0">
        <label>Username <input id="user" autocomplete="username" /></label>
        <label>Password <input id="pass" type="password" autocomplete="current-password" /></label>
        <div class="row">
          <button class="btn" id="login">Sign in</button>
          <button class="btn" id="signup">Create account</button>
        </div>
        <div class="hint" id="authMsg"></div>
      </div>
    </section>`;
  bindTop();
  $("#guest").onclick = () => {
    setSession({ guest: true });
    seedGuest();
    location.hash = "#/";
    render();
  };
  $("#login").onclick = () => {
    const u = $("#user").value.trim();
    const p = $("#pass").value;
    const hit = users().find((x) => x.user === u && x.pass === p);
    $("#authMsg").textContent = hit ? "" : "No match. Create account first.";
    if (!hit) return;
    setSession({ user: u });
    render();
  };
  $("#signup").onclick = () => {
    const u = $("#user").value.trim();
    const p = $("#pass").value;
    if (!u || !p) {
      $("#authMsg").textContent = "Username and password only.";
      return;
    }
    const all = users();
    if (all.some((x) => x.user === u)) {
      $("#authMsg").textContent = "Username taken.";
      return;
    }
    all.push({ user: u, pass: p });
    localStorage.setItem("kosh_users", JSON.stringify(all));
    setSession({ user: u });
    render();
  };
}

function seedGuest() {
  if (loadPorts().length) return;
  savePorts([{ id: "sample", name: "Sample · core", holdings: SAMPLE, bench: "nifty" }]);
}

function homeView() {
  const ports = loadPorts();
  app.innerHTML = `
    ${topbar()}
    <h1>Portfolios</h1>
    <p class="sub">Multiple portfolios. Upload broker files or add names. Dates optional.</p>
    <div class="list">
      ${
        ports.length
          ? ports
              .map(
                (p) => `
        <a class="card plist" href="#/p/${p.id}">
          <div>
            <div style="font-weight:600">${esc(p.name)}</div>
            <div class="hint">${p.holdings.length} names</div>
          </div>
          <span class="chip">Open</span>
        </a>`,
              )
              .join("")
          : `<div class="card empty">No portfolios yet.</div>`
      }
    </div>`;
  bindTop();
}

function showAddModal(existing) {
  const overlay = document.createElement("div");
  overlay.className = "modal";
  overlay.innerHTML = `
    <div class="sheet">
      <h1 style="margin-top:0;font-size:20px">${existing ? "Add to " + esc(existing.name) : "New portfolio"}</h1>
      ${existing ? "" : `<label style="margin:8px 0">Name <input id="pname" value="Main" /></label>`}
      <div class="seg" style="margin:10px 0" id="tabs">
        <button class="on" data-t="file">Files</button>
        <button data-t="manual">Manual</button>
        <button data-t="voice">Voice</button>
      </div>
      <div id="pane"></div>
      <div class="row" style="margin-top:12px;justify-content:flex-end">
        <button class="btn ghost" id="cancel">Close</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  const pane = $("#pane", overlay);
  const setTab = (t) => {
    overlay.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("on", b.dataset.t === t));
    if (t === "file") {
      pane.innerHTML = `
        <div class="drop" id="drop">Drop CSV / XLSX holdings. Multiple files ok.
          <div class="hint" style="margin-top:8px">Zerodha / Groww / Upstox holdings export.</div>
        </div>
        <input id="files" type="file" multiple accept=".csv,.xlsx,.xls,.tsv,.txt" style="margin-top:10px;width:100%" />
        <div class="hint" id="fileMsg" style="margin-top:8px"></div>`;
      const ingest = async (fileList) => {
        const files = [...fileList];
        $("#fileMsg").textContent = "Reading " + files.length + " file(s)…";
        const all = [];
        for (const f of files) {
          const b64 = await fileToB64(f);
          try {
            const r = await fetch("/api/parse-holdings", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ filename: f.name, base64: b64 }),
            });
            const d = await r.json();
            all.push(...(d.holdings || []));
          } catch {
            $("#fileMsg").textContent = "Could not parse " + f.name;
          }
        }
        if (!all.length) {
          $("#fileMsg").textContent = "No holdings found.";
          return;
        }
        commitHoldings(existing, $("#pname")?.value || "Imported", all);
        overlay.remove();
        render();
      };
      $("#files", overlay).onchange = (e) => ingest(e.target.files);
      const drop = $("#drop", overlay);
      drop.ondragover = (e) => e.preventDefault();
      drop.ondrop = (e) => {
        e.preventDefault();
        ingest(e.dataTransfer.files);
      };
    } else if (t === "manual") {
      pane.innerHTML = `
        <div class="grid g2">
          <label>Ticker <input id="msym" placeholder="RELIANCE" /></label>
          <label>Qty <input id="mqty" type="number" /></label>
          <label>Avg price (optional) <input id="mavg" type="number" /></label>
          <label>Buy date (optional) <input id="mdate" type="date" /></label>
        </div>
        <button class="btn pri" style="margin-top:10px" id="madd">Add name</button>
        <div class="hint" id="mmsg" style="margin-top:8px"></div>`;
      $("#madd", overlay).onclick = () => {
        const symbol = $("#msym").value.trim().toUpperCase();
        const qty = Number($("#mqty").value);
        const avg = Number($("#mavg").value) || null;
        const date = $("#mdate").value || null;
        if (!symbol || !(qty > 0)) {
          $("#mmsg").textContent = "Ticker and qty required.";
          return;
        }
        commitHoldings(existing, $("#pname")?.value || "Main", [{ symbol, name: symbol, qty, avg, date }]);
        overlay.remove();
        render();
      };
    } else {
      pane.innerHTML = `
        <p class="hint">Say tickers and quantities. Example: “Reliance 20, TCS 8”.</p>
        <button class="btn pri" id="rec">Start listening</button>
        <div id="vtxt" class="hint" style="margin-top:8px"></div>`;
      $("#rec", overlay).onclick = () => {
        const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SR) {
          $("#vtxt").textContent = "Voice not supported here. Use manual add.";
          return;
        }
        const rec = new SR();
        rec.lang = "en-IN";
        rec.onresult = (ev) => {
          const text = ev.results[0][0].transcript;
          $("#vtxt").textContent = text;
          const parsed = parseVoice(text);
          if (!parsed.length) return;
          commitHoldings(existing, $("#pname")?.value || "Voice", parsed);
          overlay.remove();
          render();
        };
        rec.start();
      };
    }
  };
  overlay.querySelectorAll("#tabs button").forEach((b) => (b.onclick = () => setTab(b.dataset.t)));
  $("#cancel", overlay).onclick = () => overlay.remove();
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) overlay.remove();
  });
  setTab("file");
}

function parseVoice(text) {
  const out = [];
  const re = /([A-Za-z][A-Za-z0-9&.-]{1,15})\s+(\d+(?:\.\d+)?)/g;
  let m;
  while ((m = re.exec(text))) out.push({ symbol: m[1].toUpperCase(), name: m[1], qty: Number(m[2]), avg: null, date: null });
  return out;
}

function fileToB64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}

function commitHoldings(existing, name, incoming) {
  const ports = loadPorts();
  if (existing) {
    const p = ports.find((x) => x.id === existing.id);
    const map = new Map(p.holdings.map((h) => [baseSym(h.symbol), h]));
    for (const h of incoming) {
      const k = baseSym(h.symbol);
      const cur = map.get(k);
      if (!cur) map.set(k, h);
      else {
        const q = cur.qty + h.qty;
        const avg = cur.avg && h.avg ? (cur.avg * cur.qty + h.avg * h.qty) / q : cur.avg || h.avg;
        map.set(k, { ...cur, qty: q, avg });
      }
    }
    p.holdings = [...map.values()];
  } else {
    ports.unshift({ id: uid(), name: name || "Main", holdings: incoming, bench: "nifty" });
  }
  savePorts(ports);
}

async function portfolioView(id) {
  const ports = loadPorts();
  const p = ports.find((x) => x.id === id);
  if (!p) {
    app.innerHTML = topbar() + `<p class="empty">Portfolio not found.</p>`;
    bindTop();
    return;
  }
  app.innerHTML = `
    ${topbar()}
    <div class="row" style="margin-top:16px">
      <a class="hint" href="#/">← Portfolios</a>
    </div>
    <div class="row" style="justify-content:space-between">
      <h1>${esc(p.name)}</h1>
      <div class="row">
        <button class="btn" id="addNames">Add</button>
        <button class="btn" id="insightsBtn">Insights</button>
        <button class="btn ghost" id="delPort">Delete</button>
      </div>
    </div>
    <div class="card empty" id="boot">Loading live prices and 2y history…</div>`;
  bindTop();
  $("#addNames").onclick = () => showAddModal(p);

  try {
    const book = await buildBook(p);
    drawPortfolio(p, book);
  } catch (e) {
    $("#boot").textContent = "Could not load market data. " + e.message;
  }
}

async function buildBook(p) {
  const benchKey = p.bench || "nifty";
  const benchMeta = BENCH[benchKey] || { symbol: benchKey, name: benchKey };
  const holdings = p.holdings;
  const quotes = {};
  const histories = {};
  const bookMeta = {};
  let benchBars = [];
  const q = await api("/api/quote?symbols=" + holdings.map((h) => h.symbol).join(","));
  for (const row of q.quotes || []) quotes[baseSym(row.input || row.symbol)] = row;

  try {
    const batch = await fetch("/api/histories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        symbols: [
          ...holdings.map((h) => h.symbol),
          benchMeta.symbol,
          ...new Set(Object.values(SECTOR_BENCH).map((x) => x.symbol)),
        ],
        range: "10y",
      }),
    }).then((r) => r.json());
    const byInput = {};
    for (const d of batch.rows || []) {
      const input = d.input || d.symbol;
      byInput[input] = d;
      byInput[d.symbol] = d;
      const hold = holdings.find((h) => baseSym(h.symbol) === baseSym(input));
      if (hold) {
        histories[hold.symbol] = d.bars || [];
        if (d.price) {
          quotes[baseSym(hold.symbol)] = quotes[baseSym(hold.symbol)] || {
            symbol: d.symbol,
            name: d.name,
            price: d.price,
            previousClose: d.previousClose,
            changePct: d.changePct,
            high52: d.high52,
            low52: d.low52,
          };
        }
      }
    }
    const benchRow = byInput[benchMeta.symbol] || byInput["^NSEI"];
    benchBars = benchRow?.bars || [];
    bookMeta.asOf = batch.asOf;
    bookMeta.range = batch.range;
    bookMeta.byInput = byInput;
  } catch {
    benchBars = [];
  }

  const rows = holdings.map((h) => {
    const qrow = quotes[baseSym(h.symbol)] || {};
    const px = qrow.price || h.avg || 0;
    const value = h.qty * px;
    const invested = h.avg ? h.qty * h.avg : value;
    const unreal = h.avg ? value - invested : 0;
    const unrealPct = h.avg && h.avg > 0 ? (px / h.avg - 1) * 100 : 0;
    const offHigh = qrow.high52 ? (px / qrow.high52 - 1) * 100 : null;
    return {
      ...h,
      name: qrow.name || h.name || h.symbol,
      resolved: qrow.symbol || h.symbol,
      px,
      value,
      invested,
      unreal,
      unrealPct,
      changePct: qrow.changePct || 0,
      high52: qrow.high52 || 0,
      offHigh,
      sector: sectorOf(h.symbol, qrow.sector),
      cap: capOf(h.symbol),
      periods: holdingWindows(histories[h.symbol] || []),
    };
  });

  const value = rows.reduce((s, r) => s + r.value, 0);
  const invested = rows.reduce((s, r) => s + r.invested, 0);
  rows.forEach((r) => (r.weight = value ? r.value / value : 0));
  const dayBits = rows.map((r) => saneDayPnl(r.value, r.changePct));
  const dayAbs = dayBits.reduce((s, x) => s + x.abs, 0);
  const dayPct = value ? (dayAbs / value) * 100 : 0;

  const mix = buildMixPath(
    rows.map((r) => ({ symbol: r.symbol, qty: r.qty })),
    histories,
    benchBars,
  );
  const risk = riskMetrics(mix.nav);
  const windows = {
    w1: windowReturn(mix.nav, 7),
    m1: windowReturn(mix.nav, 31),
    m3: windowReturn(mix.nav, 93),
    m6: windowReturn(mix.nav, 186),
    y1: windowReturn(mix.nav, 365),
    ytd: ytdReturn(mix.nav),
  };
  const months = monthBuckets(mix.nav);
  const cagr = mixCagr(mix.nav);

  const sectors = {};
  for (const r of rows) {
    sectors[r.sector] = sectors[r.sector] || { value: 0, pnl: 0 };
    sectors[r.sector].value += r.value;
    sectors[r.sector].pnl += r.unreal;
  }

  const sleeves = sectorSleeve(rows, histories).map((s) => {
    const spec = s.bench;
    const bars = bookMeta.byInput?.[spec.symbol]?.bars || [];
    const idx = pathFromBars(bars, []);
    return {
      ...s,
      indexName: spec.name,
      indexSymbol: spec.symbol,
      index: {
        m1: windowReturn(idx.nav, 31).port,
        m3: windowReturn(idx.nav, 93).port,
        y1: windowReturn(idx.nav, 365).port,
        ytd: ytdReturn(idx.nav).port,
      },
    };
  });

  const caps = { Large: 0, "Mid / small": 0 };
  for (const r of rows) caps[r.cap] += r.value;

  return {
    rows,
    value,
    invested,
    unreal: value - invested,
    dayAbs,
    dayPct,
    mix,
    risk,
    windows,
    months,
    cagr,
    sectors,
    sleeves,
    caps,
    asOf: bookMeta.asOf,
    hxRange: bookMeta.range || "10y",
    benchName: benchMeta.name,
    coverage: mix.coverage,
    missing: mix.missing,
    holdings: rows,
    firstDay: mix.nav[0]?.day,
    lastDay: mix.nav.at(-1)?.day,
  };
}

function drawPortfolio(p, book) {
  const { rows, value, invested, unreal, dayAbs, dayPct, mix, risk, windows, months, cagr, sectors, sleeves, caps } = book;
  const unrealPct = invested ? (unreal / invested) * 100 : 0;
  const winRows = [
    ["1W", windows.w1],
    ["1M", windows.m1],
    ["3M", windows.m3],
    ["6M", windows.m6],
    ["1Y", windows.y1],
    ["YTD", windows.ytd],
  ];
  const sectorList = Object.entries(sectors).sort((a, b) => b[1].value - a[1].value);
  const top = [...rows].sort((a, b) => b.value - a.value)[0];
  const off = rows.filter((r) => r.offHigh != null && r.offHigh <= -20).length;
  const winners = rows.filter((r) => r.unrealPct > 0).length;
  const losers = rows.filter((r) => r.unrealPct < 0).length;
  const pts = insights(book);

  app.innerHTML = `
    ${topbar()}
    <div class="row" style="margin-top:16px"><a class="hint" href="#/">← Portfolios</a></div>
    <div class="row" style="justify-content:space-between;align-items:flex-end">
      <h1>${esc(p.name)}</h1>
      <div class="row">
        <button class="btn" id="addNames">Add</button>
        <button class="btn" id="insightsBtn">Insights</button>
        <button class="btn ghost" id="delPort">Delete</button>
      </div>
    </div>
    <div class="grid g2" style="margin-top:8px">
      <div class="card"><div class="k">Current value</div><div class="v">${fmtInr(value)}</div></div>
      <div class="card"><div class="k">Invested</div><div class="v">${fmtInr(invested)}</div></div>
      <div class="card"><div class="k">Day P&L</div><div class="v ${dayAbs >= 0 ? "up" : "dn"}">${fmtInr(dayAbs)}</div><div class="s ${dayPct >= 0 ? "up" : "dn"}">${fmtPct(dayPct)}</div></div>
      <div class="card"><div class="k">Unrealized</div><div class="v ${unreal >= 0 ? "up" : "dn"}">${fmtInr(unreal)}</div><div class="s ${unrealPct >= 0 ? "up" : "dn"}">${fmtPct(unrealPct)}</div></div>
    </div>

    <div class="row" style="margin-top:14px">
      <label>Benchmark
        <select id="bench">${Object.entries(BENCH)
          .map(([k, v]) => `<option value="${k}" ${!String(p.bench || "nifty").startsWith("^") && (p.bench === k || (!p.bench && k === "nifty")) ? "selected" : ""}>${v.name}</option>`)
          .join("")}
          <option value="custom" ${String(p.bench || "").startsWith("^") || (p.bench && !BENCH[p.bench]) ? "selected" : ""}>Custom</option>
        </select>
      </label>
      <input id="customBench" placeholder="^NSEI or NIFTYBEES" value="${esc(BENCH[p.bench] ? "" : p.bench || "")}" style="width:160px;${BENCH[p.bench] || !p.bench ? "display:none" : ""}" />
      <span class="hint">Today’s mix · live 10y adj. close · dates optional</span>
    </div>
    <div class="hint" style="margin-top:6px">${esc(mix.coverage)}${book.firstDay ? ` · ${book.firstDay} → ${book.lastDay}` : ""} · method: current weights × daily returns</div>

    <h2>Returns vs ${esc(book.benchName)}</h2>
    <div class="card chartbox">
      <div class="row" style="justify-content:space-between">
        <div class="seg" id="mode">
          <button class="on" data-m="cum">Cumulative</button>
          <button data-m="roll1y">Roll 1Y</button>
          <button data-m="roll3m">Roll 3M</button>
          <button data-m="m">Monthly</button>
          <button data-m="w">Weekly</button>
          <button data-m="dd">Drawdown</button>
        </div>
        <div class="seg" id="range">
          ${["1M", "3M", "6M", "1Y", "YTD", "MAX"].map((x, i) => `<button data-r="${x}" class="${x === "1Y" ? "on" : ""}">${x}</button>`).join("")}
        </div>
      </div>
      <div class="cover" id="cov">${mix.nav.length ? mix.coverage : "No history yet"}</div>
      <canvas id="navChart"></canvas>
      ${mix.missing.length ? `<div class="hint" style="margin-top:8px">Skipped: ${mix.missing.join(", ")}</div>` : ""}
    </div>

    <h2>Windows · mix vs ${esc(book.benchName)}</h2>
    <div class="grid g3">
      ${winRows
        .map(
          ([lab, w]) => `
        <div class="card">
          <div class="k">${lab}</div>
          <div class="s">Mix <b class="${cls(w.port)}">${fmtPct(w.port)}</b></div>
          <div class="s">${esc(book.benchName)} <b class="${cls(w.bench)}">${fmtPct(w.bench)}</b></div>
        </div>`,
        )
        .join("")}
    </div>

    <h2>Risk</h2>
    <div class="grid g3">
      ${metric("Mix CAGR", dash(cagr, (x) => fmtPct(x)), "Current weights on live prices")}
      ${metric("Sharpe", dash(risk.sharpe), "Vs 6.5% risk-free")}
      ${metric("Sortino", dash(risk.sortino), "Downside only")}
      ${metric("Alpha", dash(risk.alpha, (x) => fmtPct(x)), "Jensen vs bench")}
      ${metric("Beta / corr", `${dash(risk.beta)} · ${dash(risk.corr)}`, "Aligned daily returns")}
      ${metric("Vol / max DD", `${dash(risk.vol, (x) => x.toFixed(1) + "%")} · ${dash(risk.maxDd, (x) => x.toFixed(1) + "%")}`, "Ann. vol and peak-to-trough")}
      ${metric("Up / down capture", `${dash(risk.upCap, (x) => (x * 100).toFixed(0) + "%")} / ${dash(risk.downCap, (x) => (x * 100).toFixed(0) + "%")}`, "Vs bench up and down days")}
      ${metric("Info ratio", dash(risk.info), "Excess / tracking error")}
      ${metric("Calmar", dash(risk.calmar), "CAGR / |max DD|")}
    </div>

    <h2>Month heatmap</h2>
    <div class="card">${renderHeat(months)}</div>

    <h2>Contribution · unrealized</h2>
    <div class="card barwrap">
      ${[...rows]
        .sort((a, b) => Math.abs(b.unreal) - Math.abs(a.unreal))
        .slice(0, 8)
        .map((r) => {
          const max = Math.max(...rows.map((x) => Math.abs(x.unreal)), 1);
          const w = (Math.abs(r.unreal) / max) * 100;
          return `<div class="barline"><div>${esc(r.symbol)}</div><div class="track"><div class="fill" style="width:${w}%;background:${r.unreal >= 0 ? "var(--green)" : "var(--red)"}"></div></div><div class="right ${r.unreal >= 0 ? "up" : "dn"}">${fmtInr(r.unreal)}</div></div>`;
        })
        .join("")}
    </div>

    <h2>Allocation</h2>
    <div class="grid g2">
      <div class="card barwrap">
        <div class="k">Sectors</div>
        ${
          sectorList
            .map(([name, s]) => {
              const w = value ? (s.value / value) * 100 : 0;
              return `<div class="barline"><div>${esc(name)}</div><div class="track"><div class="fill" style="width:${w}%"></div></div><div class="right">${w.toFixed(0)}%</div></div>`;
            })
            .join("") || `<div class="hint">No sector data</div>`
        }
      </div>
      <div class="card barwrap">
        <div class="k">Market cap</div>
        ${Object.entries(caps || {})
          .map(([name, v]) => {
            const w = value ? (v / value) * 100 : 0;
            return `<div class="barline"><div>${esc(name)}</div><div class="track"><div class="fill" style="width:${w}%"></div></div><div class="right">${w.toFixed(0)}%</div></div>`;
          })
          .join("")}
      </div>
    </div>

    <h2>Sector vs index</h2>
    <div class="card" style="overflow:auto">
      <table>
        <thead><tr><th>Sector</th><th class="right">Wt</th><th class="right">1M sleeve</th><th class="right">1M index</th><th class="right">1Y sleeve</th><th class="right">1Y index</th><th class="right">Gap 1Y</th><th>Index</th></tr></thead>
        <tbody>
          ${(sleeves || [])
            .map((s) => {
              const w = value ? (s.value / value) * 100 : 0;
              const gap = s.windows.y1 != null && s.index.y1 != null ? s.windows.y1 - s.index.y1 : null;
              return `<tr>
                <td>${esc(s.sector)}<div class="hint">${s.names} names</div></td>
                <td class="right">${w.toFixed(0)}%</td>
                <td class="right ${cls(s.windows.m1)}">${fmtPct(s.windows.m1)}</td>
                <td class="right ${cls(s.index.m1)}">${fmtPct(s.index.m1)}</td>
                <td class="right ${cls(s.windows.y1)}">${fmtPct(s.windows.y1)}</td>
                <td class="right ${cls(s.index.y1)}">${fmtPct(s.index.y1)}</td>
                <td class="right ${cls(gap)}">${fmtPct(gap, 1)}</td>
                <td>${esc(s.indexName)}</td>
              </tr>`;
            })
            .join("")}
        </tbody>
      </table>
      <div class="hint" style="margin-top:8px">Sleeve = current names in that sector, same current-mix method. Index is the live sector benchmark (ETF used where Yahoo has no daily index series).</div>
    </div>

    <h2>Investor view</h2>
    <div class="grid g2">
      ${metric("Names", String(rows.length), "Live holdings")}
      ${metric("Top weight", top ? (top.weight * 100).toFixed(0) + "% " + top.symbol : "—", "Largest line")}
      ${metric("Off 52w high", off ? off + " names" : "None", "≥20% below high")}
      ${metric("Winners / losers", winners + " / " + losers, "Vs average price")}
    </div>

    <div id="insightBox" hidden>
      <h2>Insights</h2>
      <div class="points">
        ${pts
          .map(
            (x) => `<div class="pt ${x.tone}"><div><div class="k">${esc(x.title)}</div><div class="fig">${esc(x.figure)}</div></div><div class="bd">${esc(x.body)}</div></div>`,
          )
          .join("")}
      </div>
    </div>

    <h2>Holdings</h2>
    <div class="card" style="overflow:auto">
      <table>
        <thead><tr><th>Name</th><th class="right">Wt</th><th class="right">Value</th><th class="right">1D</th><th class="right">1M</th><th class="right">3M</th><th class="right">1Y</th><th class="right">YTD</th><th class="right">Unreal</th></tr></thead>
        <tbody>
          ${rows
            .sort((a, b) => b.value - a.value)
            .map(
              (r) => `
            <tr>
              <td><span class="sym" data-s="${esc(r.symbol)}">${esc(r.symbol)}</span><div class="hint">${esc(r.sector)} · ${esc(r.cap)}</div></td>
              <td class="right">${(r.weight * 100).toFixed(1)}%</td>
              <td class="right">${fmtInr(r.value)}</td>
              <td class="right ${cls(r.changePct)}">${fmtPct(r.changePct)}</td>
              <td class="right ${cls(r.periods?.m1)}">${fmtPct(r.periods?.m1)}</td>
              <td class="right ${cls(r.periods?.m3)}">${fmtPct(r.periods?.m3)}</td>
              <td class="right ${cls(r.periods?.y1)}">${fmtPct(r.periods?.y1)}</td>
              <td class="right ${cls(r.periods?.ytd)}">${fmtPct(r.periods?.ytd)}</td>
              <td class="right ${cls(r.unrealPct)}">${fmtPct(r.unrealPct)}</td>
            </tr>`,
            )
            .join("")}
        </tbody>
      </table>
    </div>`;

  bindTop();
  $("#addNames").onclick = () => showAddModal(p);
  $("#delPort").onclick = () => {
    if (!confirm("Delete this portfolio?")) return;
    savePorts(loadPorts().filter((x) => x.id !== p.id));
    location.hash = "#/";
    render();
  };
  $("#insightsBtn").onclick = () => {
    const box = $("#insightBox");
    box.hidden = !box.hidden;
    if (!box.hidden) box.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const applyBench = () => {
    const ports = loadPorts();
    const hit = ports.find((x) => x.id === p.id);
    const sel = $("#bench").value;
    if (sel === "custom") {
      $("#customBench").style.display = "";
      const raw = $("#customBench").value.trim();
      if (!raw) return;
      hit.bench = raw;
    } else {
      $("#customBench").style.display = "none";
      hit.bench = sel;
    }
    savePorts(ports);
    portfolioView(p.id);
  };
  $("#bench").onchange = applyBench;
  $("#customBench").onchange = applyBench;
  document.querySelectorAll(".sym").forEach((el) => {
    el.onclick = () => {
      location.hash = "#/s/" + el.dataset.s;
    };
  });

  let mode = "cum";
  let range = "1Y";
  const paint = () => drawChart(mix.nav, mode, range, book.benchName);
  paint();
  document.querySelectorAll("#mode button").forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll("#mode button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      mode = b.dataset.m;
      paint();
    };
  });
  document.querySelectorAll("#range button").forEach((b) => {
    b.onclick = () => {
      document.querySelectorAll("#range button").forEach((x) => x.classList.remove("on"));
      b.classList.add("on");
      range = b.dataset.r;
      paint();
    };
  });
}

function metric(k, v, s) {
  return `<div class="card"><div class="k">${k}</div><div class="v" style="font-size:18px">${v}</div><div class="s">${s}</div></div>`;
}
function cls(n) {
  if (n == null) return "";
  return n >= 0 ? "up" : "dn";
}

function renderHeat(months) {
  if (!months.length) return `<div class="hint">Need a few months of mix path.</div>`;
  const years = [...new Set(months.map((m) => m.key.slice(0, 4)))];
  const labels = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
  let html = `<div class="heat"><div></div>${labels.map((l) => `<div class="hint" style="text-align:center">${l}</div>`).join("")}`;
  for (const y of years) {
    html += `<div class="y">${y}</div>`;
    for (let i = 1; i <= 12; i++) {
      const k = y + "-" + String(i).padStart(2, "0");
      const row = months.find((m) => m.key === k);
      if (!row) {
        html += `<div class="m" style="background:#151922"></div>`;
        continue;
      }
      const v = row.port;
      const bg = heatColor(v);
      html += `<div class="m" style="background:${bg}" title="${k} ${v.toFixed(1)}%">${v.toFixed(0)}</div>`;
    }
  }
  html += `</div>`;
  return html;
}
function heatColor(v) {
  if (v >= 8) return "#2f9e66";
  if (v >= 3) return "#3dd68c";
  if (v >= 0) return "#9be7c4";
  if (v >= -3) return "#f5b4b4";
  if (v >= -8) return "#ff6b6b";
  return "#c43c3c";
}

function drawChart(nav, mode, range, benchName) {
  const ctx = document.getElementById("navChart");
  if (!ctx || typeof Chart === "undefined") return;
  if (chartRef) {
    chartRef.destroy();
    chartRef = null;
  }
  if (nav.length < 3) {
    return;
  }
  const sliced = sliceNav(nav, range);
  let labels, a, b, yTitle;
  if (mode === "dd") {
    const idx = withDrawdown(toIndexed(sliced));
    labels = idx.map((p) => p.day);
    a = idx.map((p) => p.dd);
    b = null;
    yTitle = "Drawdown %";
  } else if (mode === "roll" || mode === "roll1y" || mode === "roll3m") {
    const days = mode === "roll3m" ? 93 : 365;
    const rs = rollingSeries(sliced.length > 20 ? sliced : nav, days);
    labels = rs.map((p) => p.day);
    a = rs.map((p) => p.port);
    b = rs.map((p) => p.bench);
    yTitle = mode === "roll3m" ? "Rolling 3M %" : "Rolling 1Y %";
  } else if (mode === "m") {
    const ms = monthBuckets(sliced.length > 10 ? sliced : nav);
    labels = ms.map((p) => p.key);
    a = ms.map((p) => p.port);
    b = ms.map((p) => p.bench);
    yTitle = "Month %";
  } else if (mode === "w") {
    const ws = weekBuckets(sliced.length > 10 ? sliced : nav);
    labels = ws.map((p) => p.key);
    a = ws.map((p) => p.port);
    b = ws.map((p) => p.bench);
    yTitle = "Week %";
  } else {
    const idx = toIndexed(sliced);
    labels = idx.map((p) => p.day);
    a = idx.map((p) => p.portIdx);
    b = idx.map((p) => p.benchIdx);
    yTitle = "Indexed 100";
  }
  const datasets = [
    {
      label: "Mix",
      data: a,
      borderColor: "#7aa2ff",
      backgroundColor: "rgba(122,162,255,.12)",
      fill: mode === "cum",
      tension: 0.15,
      pointRadius: 0,
      borderWidth: 1.6,
    },
  ];
  if (b && b.some((x) => x != null)) {
    datasets.push({
      label: benchName,
      data: b,
      borderColor: "#8b95a7",
      tension: 0.15,
      pointRadius: 0,
      borderWidth: 1.3,
      borderDash: [4, 3],
    });
  }
  chartRef = new Chart(ctx, {
    type: mode === "m" || mode === "w" ? "bar" : "line",
    data: { labels, datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: "index", intersect: false },
      plugins: {
        legend: { labels: { color: "#8b95a7", boxWidth: 10, font: { size: 11 } } },
        tooltip: {
          callbacks: {
            label: (c) => `${c.dataset.label}: ${Number(c.parsed.y).toFixed(2)}`,
          },
        },
      },
      scales: {
        x: { ticks: { color: "#5c6678", maxTicksLimit: 8, font: { size: 10 } }, grid: { display: false } },
        y: { ticks: { color: "#5c6678", font: { size: 10 } }, grid: { color: "#1a1f28" }, title: { display: true, text: yTitle, color: "#5c6678" } },
      },
    },
  });
}

async function compareView() {
  const ports = loadPorts();
  const names = [...new Set(ports.flatMap((p) => p.holdings.map((h) => h.symbol)))];
  app.innerHTML = `
    ${topbar()}
    <h1>Compare</h1>
    <p class="sub">Portfolio vs portfolio, or any stock vs an index.</p>
    <div class="grid g2">
      <label>Left
        <select id="aType"><option value="port">Portfolio</option><option value="stock">Stock</option></select>
        <select id="aPort">${ports.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join("")}</select>
        <input id="aStock" placeholder="RELIANCE" list="tickers" />
      </label>
      <label>Right
        <select id="bType"><option value="port">Portfolio</option><option value="stock">Stock</option><option value="bench">Benchmark</option></select>
        <select id="bPort">${ports.map((p, i) => `<option value="${p.id}" ${i === 1 ? "selected" : ""}>${esc(p.name)}</option>`).join("")}</select>
        <input id="bStock" placeholder="TCS" list="tickers" />
        <select id="bBench">${Object.entries(BENCH).map(([k, v]) => `<option value="${k}">${v.name}</option>`).join("")}</select>
      </label>
    </div>
    <datalist id="tickers">${names.map((s) => `<option value="${esc(s)}">`).join("")}</datalist>
    <button class="btn pri" style="margin:12px 0" id="go">Run</button>
    <div id="outBox"></div>`;
  bindTop();
  const sync = () => {
    $("#aPort").style.display = $("#aType").value === "port" ? "" : "none";
    $("#aStock").style.display = $("#aType").value === "stock" ? "" : "none";
    $("#bPort").style.display = $("#bType").value === "port" ? "" : "none";
    $("#bStock").style.display = $("#bType").value === "stock" ? "" : "none";
    $("#bBench").style.display = $("#bType").value === "bench" ? "" : "none";
  };
  $("#aType").onchange = sync;
  $("#bType").onchange = sync;
  sync();
  $("#go").onclick = async () => {
    $("#outBox").innerHTML = `<div class="card empty">Fetching 10y live history…</div>`;
    const A = await loadCompareLeg($("#aType").value, { portId: $("#aPort").value, stock: $("#aStock").value, bench: "nifty" });
    const B = await loadCompareLeg($("#bType").value, { portId: $("#bPort").value, stock: $("#bStock").value, bench: $("#bBench").value });
    if (!A || !B) {
      $("#outBox").innerHTML = `<div class="card empty">Could not resolve both sides.</div>`;
      return;
    }
    $("#outBox").innerHTML = `
      <div class="grid g2">
        ${compareCard(A)}
        ${compareCard(B)}
      </div>
      <div class="grid g3" style="margin-top:10px">
        ${["m1","m3","y1","ytd"].map((k) => {
          const gap = (A.windows[k]?.port ?? null) != null && (B.windows[k]?.port ?? null) != null ? A.windows[k].port - B.windows[k].port : null;
          const lab = { m1: "1M", m3: "3M", y1: "1Y", ytd: "YTD" }[k];
          return `<div class="card"><div class="k">${lab} gap</div><div class="v ${cls(gap)}">${fmtPct(gap)}</div><div class="s">Left minus right</div></div>`;
        }).join("")}
      </div>
      <div class="card chartbox" style="margin-top:12px">
        <div class="seg" id="mode">
          <button class="on" data-m="cum">Cumulative</button>
          <button data-m="roll1y">Roll 1Y</button>
          <button data-m="m">Monthly</button>
          <button data-m="dd">Drawdown</button>
        </div>
        <div class="seg" id="range">${["1M","3M","6M","1Y","YTD","MAX"].map((x) => `<button data-r="${x}" class="${x==="1Y"?"on":""}">${x}</button>`).join("")}</div>
        <canvas id="navChart"></canvas>
      </div>`;
    const merged = mergeNav(A.mix.nav, B.mix.nav, A.name, B.name);
    let mode = "cum", range = "1Y";
    const paint = () => drawCompareChart(merged, mode, range, A.name, B.name);
    paint();
    document.querySelectorAll("#mode button").forEach((b) => (b.onclick = () => { document.querySelectorAll("#mode button").forEach((x) => x.classList.remove("on")); b.classList.add("on"); mode = b.dataset.m; paint(); }));
    document.querySelectorAll("#range button").forEach((b) => (b.onclick = () => { document.querySelectorAll("#range button").forEach((x) => x.classList.remove("on")); b.classList.add("on"); range = b.dataset.r; paint(); }));
  };
}

function compareCard(x) {
  return `<div class="card"><div class="k">${esc(x.name)}</div><div class="v">${x.value ? fmtInr(x.value) : fmtPct(x.windows.y1.port)}</div>
    <div class="s">1M ${fmtPct(x.windows.m1.port)} · 1Y ${fmtPct(x.windows.y1.port)} · CAGR ${dash(x.cagr, (n) => fmtPct(n))}</div>
    <div class="s">${esc(x.mix.coverage)}</div></div>`;
}

async function loadCompareLeg(type, opts) {
  if (type === "port") {
    const p = loadPorts().find((x) => x.id === opts.portId);
    if (!p) return null;
    const book = await buildBook(p);
    return { name: p.name, value: book.value, windows: book.windows, cagr: book.cagr, mix: book.mix };
  }
  if (type === "stock") {
    const sym = (opts.stock || "").trim();
    if (!sym) return null;
    const d = await api("/api/history?symbol=" + encodeURIComponent(sym) + "&range=10y");
    const mix = pathFromBars(d.bars || [], []);
    return { name: d.name || sym, value: d.price, windows: { m1: windowReturn(mix.nav, 31), m3: windowReturn(mix.nav, 93), y1: windowReturn(mix.nav, 365), ytd: ytdReturn(mix.nav) }, cagr: mixCagr(mix.nav), mix };
  }
  const spec = BENCH[opts.bench] || BENCH.nifty;
  const d = await api("/api/history?symbol=" + encodeURIComponent(spec.symbol) + "&range=10y");
  const mix = pathFromBars(d.bars || [], []);
  return { name: spec.name, value: d.price, windows: { m1: windowReturn(mix.nav, 31), m3: windowReturn(mix.nav, 93), y1: windowReturn(mix.nav, 365), ytd: ytdReturn(mix.nav) }, cagr: mixCagr(mix.nav), mix };
}

function mergeNav(a, b) {
  const mb = new Map(b.map((p) => [p.day, p]));
  return a.filter((p) => mb.has(p.day)).map((p) => ({ t: p.t, day: p.day, port: p.port, bench: mb.get(p.day).port }));
}

function drawCompareChart(nav, mode, range, leftName, rightName) {
  drawChart(nav, mode, range, rightName);
  if (chartRef) {
    chartRef.data.datasets[0].label = leftName;
    if (chartRef.data.datasets[1]) chartRef.data.datasets[1].label = rightName;
    chartRef.update();
  }
}

async function stockView(sym) {
  app.innerHTML = `${topbar()}<h1>${esc(sym)}</h1><div class="card empty">Loading 10y live history…</div>`;
  bindTop();
  try {
    const benchSel = "nifty";
    const d = await api("/api/history?symbol=" + encodeURIComponent(sym) + "&range=10y");
    await showStock(sym, d, benchSel);
  } catch {
    app.innerHTML = `${topbar()}<p class="empty">No history for ${esc(sym)}.</p>`;
    bindTop();
  }
}

async function showStock(sym, d, benchKey) {
  const spec = BENCH[benchKey] || BENCH.nifty;
  const n = await api("/api/history?symbol=" + encodeURIComponent(spec.symbol) + "&range=10y");
  const mix = pathFromBars(d.bars || [], n.bars || []);
  const risk = riskMetrics(mix.nav);
  const windows = {
    w1: windowReturn(mix.nav, 7),
    m1: windowReturn(mix.nav, 31),
    m3: windowReturn(mix.nav, 93),
    m6: windowReturn(mix.nav, 186),
    y1: windowReturn(mix.nav, 365),
    ytd: ytdReturn(mix.nav),
  };
  const cagr = mixCagr(mix.nav);
  const months = monthBuckets(mix.nav);
  app.innerHTML = `
    ${topbar()}
    <div class="row" style="margin-top:16px"><a class="hint" href="javascript:history.back()">← Back</a></div>
    <div class="row" style="justify-content:space-between;align-items:flex-end">
      <h1>${esc(d.name || sym)}</h1>
      <label>Benchmark
        <select id="bench">${Object.entries(BENCH).map(([k, v]) => `<option value="${k}" ${k===benchKey?"selected":""}>${v.name}</option>`).join("")}</select>
      </label>
    </div>
    <div class="hint">${mix.coverage} · adj close · ${d.sessions || (d.bars||[]).length} prints</div>
    <div class="grid g3" style="margin-top:10px">
      <div class="card"><div class="k">Price</div><div class="v">${d.price?.toLocaleString("en-IN") || "—"}</div><div class="s ${cls(d.changePct)}">${fmtPct(d.changePct)}</div></div>
      <div class="card"><div class="k">52w high</div><div class="v">${d.high52?.toLocaleString("en-IN") || "—"}</div></div>
      <div class="card"><div class="k">52w low</div><div class="v">${d.low52?.toLocaleString("en-IN") || "—"}</div></div>
    </div>
    <h2>Returns vs ${esc(spec.name)}</h2>
    <div class="card chartbox">
      <div class="row" style="justify-content:space-between">
        <div class="seg" id="mode">
          <button class="on" data-m="cum">Cumulative</button>
          <button data-m="roll1y">Roll 1Y</button>
          <button data-m="roll3m">Roll 3M</button>
          <button data-m="m">Monthly</button>
          <button data-m="w">Weekly</button>
          <button data-m="dd">Drawdown</button>
        </div>
        <div class="seg" id="range">${["1M","3M","6M","1Y","YTD","MAX"].map((x) => `<button data-r="${x}" class="${x==="1Y"?"on":""}">${x}</button>`).join("")}</div>
      </div>
      <canvas id="navChart"></canvas>
    </div>
    <h2>Windows</h2>
    <div class="grid g3">
      ${[["1W",windows.w1],["1M",windows.m1],["3M",windows.m3],["6M",windows.m6],["1Y",windows.y1],["YTD",windows.ytd]].map(([lab,w]) => `
        <div class="card"><div class="k">${lab}</div>
          <div class="s">Stock <b class="${cls(w.port)}">${fmtPct(w.port)}</b></div>
          <div class="s">${esc(spec.name)} <b class="${cls(w.bench)}">${fmtPct(w.bench)}</b></div>
        </div>`).join("")}
    </div>
    <h2>Risk vs ${esc(spec.name)}</h2>
    <div class="grid g3">
      ${metric("CAGR", dash(cagr, (x) => fmtPct(x)), "From first common print")}
      ${metric("Sharpe", dash(risk.sharpe), "Vs 6.5% risk-free")}
      ${metric("Sortino", dash(risk.sortino), "Downside only")}
      ${metric("Alpha", dash(risk.alpha, (x) => fmtPct(x)), "Jensen")}
      ${metric("Beta / corr", `${dash(risk.beta)} · ${dash(risk.corr)}`, "Aligned daily")}
      ${metric("Vol / max DD", `${dash(risk.vol, (x) => x.toFixed(1)+"%")} · ${dash(risk.maxDd, (x) => x.toFixed(1)+"%")}`, "")}
    </div>
    <h2>Month heatmap</h2>
    <div class="card">${renderHeat(months)}</div>`;
  bindTop();
  $("#bench").onchange = () => showStock(sym, d, $("#bench").value);
  let mode = "cum", range = "1Y";
  const paint = () => drawChart(mix.nav, mode, range, spec.name);
  paint();
  document.querySelectorAll("#mode button").forEach((b) => (b.onclick = () => { document.querySelectorAll("#mode button").forEach((x) => x.classList.remove("on")); b.classList.add("on"); mode = b.dataset.m; paint(); }));
  document.querySelectorAll("#range button").forEach((b) => (b.onclick = () => { document.querySelectorAll("#range button").forEach((x) => x.classList.remove("on")); b.classList.add("on"); range = b.dataset.r; paint(); }));
}

function esc(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

render();
