/* Kosh mix-path + risk. Calendar-day forward-fill. Never require every ticker on every date. */

const IST = "Asia/Kolkata";
const RF = 0.065;

export function istDay(unixSec) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: IST,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(unixSec * 1000));
}

/**
 * Current-mix path.
 * Today's weights × each name's own daily return.
 * A name listing halfway through does not jump portfolio value.
 * Days with <60% of weight printing are dropped.
 */
export function buildMixPath(holdings, histories, benchBars) {
  const withHx = holdings.filter((h) => (histories[h.symbol] || []).length >= 5);
  const missing = holdings
    .filter((h) => !withHx.some((x) => x.symbol === h.symbol))
    .map((h) => h.symbol);
  const used = withHx.map((h) => h.symbol);
  if (!withHx.length) {
    return { nav: [], used, missing, coverage: `0/${holdings.length} names · 0 sessions`, method: "current-mix" };
  }

  const maps = withHx.map((h) => ({ h, m: toDayMap(histories[h.symbol]) }));
  const weights = currentWeights(withHx, maps);
  const benchMap = toDayMap(benchBars || []);
  const days = new Set();
  for (const { m } of maps) for (const d of m.keys()) days.add(d);

  const prev = {};
  let navPx = 100;
  let benchPx = 100;
  let bench0 = null;
  const nav = [];

  for (const day of [...days].sort()) {
    let wr = 0;
    let wAvail = 0;
    let live = 0;
    let t = 0;
    for (const { h, m } of maps) {
      const hit = m.get(day);
      if (!hit) continue;
      live += 1;
      t = t || hit.t;
      if (prev[h.symbol] > 0) {
        const w = weights[h.symbol] || 0;
        wr += w * (hit.c / prev[h.symbol] - 1);
        wAvail += w;
      }
      prev[h.symbol] = hit.c;
    }
    if (live === 0 || wAvail < 0.6) continue;
    const portR = wr / wAvail;
    navPx *= 1 + portR;
    const b = benchMap.get(day);
    let benchVal = null;
    if (b && b.c > 0) {
      if (!bench0) bench0 = b.c;
      benchVal = (b.c / bench0) * 100;
      benchPx = benchVal;
      t = b.t || t;
    }
    nav.push({
      t,
      day,
      port: navPx,
      bench: benchVal,
      covered: Object.keys(prev).length,
      names: withHx.length,
      wAvail,
    });
  }

  return {
    nav,
    used,
    missing,
    weights,
    coverage: `${used.length}/${holdings.length} names · ${nav.length} sessions`,
    method: "current-mix",
  };
}

function currentWeights(withHx, maps) {
  const w = {};
  let sum = 0;
  for (const { h, m } of maps) {
    const last = [...m.values()].at(-1);
    const px = last?.c || 0;
    const val = (h.qty || 1) * px;
    w[h.symbol] = val;
    sum += val;
  }
  if (sum <= 0) {
    const eq = 1 / withHx.length;
    for (const { h } of maps) w[h.symbol] = eq;
    return w;
  }
  for (const k of Object.keys(w)) w[k] = w[k] / sum;
  return w;
}

export function pathFromBars(bars, benchBars) {
  return buildMixPath([{ symbol: "_s", qty: 1 }], { _s: bars || [] }, benchBars || []);
}

function toDayMap(bars) {
  const m = new Map();
  for (const b of bars || []) {
    if (!b || !(b.c > 0)) continue;
    m.set(istDay(b.t), { day: istDay(b.t), t: b.t, c: b.c });
  }
  return m;
}

export function sliceNav(nav, range) {
  if (!nav.length) return nav;
  const last = nav[nav.length - 1].t;
  const days =
    range === "1M" ? 31 : range === "3M" ? 93 : range === "6M" ? 186 : range === "1Y" ? 372 : range === "YTD" ? null : 800;
  if (range === "YTD") {
    const y = nav[nav.length - 1].day.slice(0, 4);
    return nav.filter((p) => p.day.startsWith(y));
  }
  if (!days) return nav;
  const cut = last - days * 86400;
  const s = nav.filter((p) => p.t >= cut);
  return s.length >= 2 ? s : nav.slice(-2);
}

export function toIndexed(nav) {
  const p0 = nav.find((p) => p.port > 0);
  const b0 = nav.find((p) => p.bench > 0);
  if (!p0) return [];
  return nav.map((p) => ({
    ...p,
    portIdx: (p.port / p0.port) * 100,
    benchIdx: p.bench && b0 ? (p.bench / b0.bench) * 100 : null,
    dd: 0,
  }));
}

export function withDrawdown(indexed) {
  let peak = 0;
  return indexed.map((p) => {
    peak = Math.max(peak, p.portIdx);
    return { ...p, dd: peak ? ((p.portIdx - peak) / peak) * 100 : 0 };
  });
}

export function windowReturn(nav, days) {
  if (nav.length < 2) return { port: null, bench: null };
  const last = nav[nav.length - 1];
  const cut = last.t - days * 86400;
  let first = nav[0];
  for (const p of nav) if (p.t <= cut) first = p;
  const port = first.port ? (last.port / first.port - 1) * 100 : null;
  const bench =
    first.bench && last.bench ? (last.bench / first.bench - 1) * 100 : null;
  return { port, bench };
}

export function ytdReturn(nav) {
  if (nav.length < 2) return { port: null, bench: null };
  const y = nav[nav.length - 1].day.slice(0, 4);
  const first = nav.find((p) => p.day.startsWith(y)) || nav[0];
  const last = nav[nav.length - 1];
  return {
    port: first.port ? (last.port / first.port - 1) * 100 : null,
    bench: first.bench && last.bench ? (last.bench / first.bench - 1) * 100 : null,
  };
}

export function mixCagr(nav) {
  if (nav.length < 5) return null;
  const a = nav[0];
  const b = nav[nav.length - 1];
  const yrs = Math.max((b.t - a.t) / (365.25 * 86400), 1 / 365);
  if (!(a.port > 0) || !(b.port > 0)) return null;
  return (Math.pow(b.port / a.port, 1 / yrs) - 1) * 100;
}

export function dailyRets(series) {
  const r = [];
  for (let i = 1; i < series.length; i++) {
    const a = series[i - 1];
    const b = series[i];
    if (a > 0 && b > 0) r.push(b / a - 1);
  }
  return r;
}

function alignedRets(nav) {
  const pr = [];
  const br = [];
  for (let i = 1; i < nav.length; i++) {
    const a = nav[i - 1];
    const b = nav[i];
    if (a.port > 0 && b.port > 0 && a.bench > 0 && b.bench > 0) {
      pr.push(b.port / a.port - 1);
      br.push(b.bench / a.bench - 1);
    }
  }
  return { pr, br };
}

export function riskMetrics(nav) {
  const empty = {
    sharpe: null,
    sortino: null,
    alpha: null,
    beta: null,
    corr: null,
    vol: null,
    maxDd: null,
    upCap: null,
    downCap: null,
    info: null,
    calmar: null,
  };
  if (!nav || nav.length < 10) return empty;
  const port = nav.map((p) => p.port);
  const rets = dailyRets(port);
  if (rets.length < 8) return empty;
  const volD = stdev(rets);
  const vol = volD * Math.sqrt(252) * 100;
  const mean = avg(rets);
  const ann = mean * 252;
  const sharpe = volD ? ((ann - RF) / (volD * Math.sqrt(252))) : null;
  const down = rets.filter((x) => x < 0);
  const ds = down.length ? stdev(down) : 0;
  const sortino = ds ? (ann - RF) / (ds * Math.sqrt(252)) : null;
  const idx = withDrawdown(toIndexed(nav));
  const maxDd = Math.min(...idx.map((p) => p.dd));
  const cagr = mixCagr(nav);
  const calmar = maxDd && maxDd < 0 && cagr != null ? cagr / Math.abs(maxDd) : null;

  const { pr, br } = alignedRets(nav);
  let beta = null,
    alpha = null,
    corr = null,
    upCap = null,
    downCap = null,
    info = null;
  if (pr.length >= 8) {
    const cov = covariance(pr, br);
    const vb = variance(br);
    beta = vb ? cov / vb : null;
    corr = corrcoef(pr, br);
    const rp = avg(pr) * 252;
    const rb = avg(br) * 252;
    alpha = beta != null ? (rp - RF - beta * (rb - RF)) * 100 : null;
    const upP = [],
      upB = [],
      dnP = [],
      dnB = [];
    for (let i = 0; i < pr.length; i++) {
      if (br[i] >= 0) {
        upP.push(pr[i]);
        upB.push(br[i]);
      } else {
        dnP.push(pr[i]);
        dnB.push(br[i]);
      }
    }
    upCap = avg(upB) ? avg(upP) / avg(upB) : null;
    downCap = avg(dnB) ? avg(dnP) / avg(dnB) : null;
    const excess = pr.map((x, i) => x - br[i]);
    const te = stdev(excess) * Math.sqrt(252);
    info = te ? ((avg(excess) * 252) / te) : null;
  }
  return { sharpe, sortino, alpha, beta, corr, vol, maxDd, upCap, downCap, info, calmar, cagr };
}

export function monthBuckets(nav) {
  const m = new Map();
  for (const p of nav) {
    const k = p.day.slice(0, 7);
    if (!m.has(k)) m.set(k, p);
    m.set("__last_" + k, p);
  }
  const keys = [...new Set(nav.map((p) => p.day.slice(0, 7)))].sort();
  const rows = [];
  for (let i = 0; i < keys.length; i++) {
    const k = keys[i];
    const last = nav.filter((p) => p.day.startsWith(k)).at(-1);
    const first = i === 0 ? nav.find((p) => p.day.startsWith(k)) : nav.filter((p) => p.day.startsWith(keys[i - 1])).at(-1);
    if (!first || !last || first.port <= 0) continue;
    const span = last.t - first.t;
    if (span < 8 * 86400 && i === 0) continue;
    rows.push({
      key: k,
      port: (last.port / first.port - 1) * 100,
      bench: first.bench && last.bench ? (last.bench / first.bench - 1) * 100 : null,
    });
  }
  return rows;
}

export function weekBuckets(nav) {
  const m = new Map();
  for (const p of nav) {
    const d = new Date(p.t * 1000);
    const wk = new Date(d);
    wk.setUTCDate(d.getUTCDate() - ((d.getUTCDay() + 6) % 7));
    const k = wk.toISOString().slice(0, 10);
    m.set(k, p);
  }
  const keys = [...m.keys()].sort();
  const rows = [];
  for (let i = 1; i < keys.length; i++) {
    const a = m.get(keys[i - 1]);
    const b = m.get(keys[i]);
    if (!a.port || !b.port) continue;
    rows.push({
      key: keys[i],
      port: (b.port / a.port - 1) * 100,
      bench: a.bench && b.bench ? (b.bench / a.bench - 1) * 100 : null,
    });
  }
  return rows;
}

export function rollingSeries(nav, winDays) {
  const out = [];
  for (let i = 0; i < nav.length; i++) {
    const cut = nav[i].t - winDays * 86400;
    let j = i;
    while (j > 0 && nav[j].t > cut) j--;
    if (nav[i].t - nav[j].t < winDays * 86400 * 0.7) continue;
    if (!(nav[j].port > 0)) continue;
    out.push({
      t: nav[i].t,
      day: nav[i].day,
      port: (nav[i].port / nav[j].port - 1) * 100,
      bench:
        nav[j].bench && nav[i].bench ? (nav[i].bench / nav[j].bench - 1) * 100 : null,
    });
  }
  return out;
}

function avg(a) {
  return a.length ? a.reduce((s, x) => s + x, 0) / a.length : 0;
}
function variance(a) {
  if (a.length < 2) return 0;
  const m = avg(a);
  return a.reduce((s, x) => s + (x - m) ** 2, 0) / (a.length - 1);
}
function stdev(a) {
  return Math.sqrt(variance(a));
}
function covariance(a, b) {
  const n = Math.min(a.length, b.length);
  if (n < 2) return 0;
  const ma = avg(a.slice(0, n));
  const mb = avg(b.slice(0, n));
  let s = 0;
  for (let i = 0; i < n; i++) s += (a[i] - ma) * (b[i] - mb);
  return s / (n - 1);
}
function corrcoef(a, b) {
  const sa = stdev(a);
  const sb = stdev(b);
  if (!sa || !sb) return null;
  return covariance(a, b) / (sa * sb);
}

export function fmtInr(n) {
  if (n == null || !Number.isFinite(n)) return "—";
  const abs = Math.abs(n);
  const sign = n < 0 ? "-" : "";
  if (abs >= 1e7) return sign + (abs / 1e7).toFixed(2) + " Cr";
  if (abs >= 1e5) return sign + (abs / 1e5).toFixed(2) + " L";
  return sign + abs.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

export function fmtPct(n, d = 2) {
  if (n == null || !Number.isFinite(n)) return "—";
  const s = (n >= 0 ? "+" : "") + n.toFixed(d) + "%";
  return s;
}

export function dash(n, fmt = (x) => x.toFixed(2)) {
  if (n == null || !Number.isFinite(n)) return "—";
  return fmt(n);
}

export function saneDayPnl(value, changePct) {
  if (!Number.isFinite(changePct) || Math.abs(changePct) > 25) return { abs: 0, pct: 0 };
  return { abs: value * (changePct / 100), pct: changePct };
}

export const SECTORS = {
  RELIANCE: "Energy",
  TCS: "IT",
  INFY: "IT",
  WIPRO: "IT",
  HCLTECH: "IT",
  TECHM: "IT",
  LTIM: "IT",
  PERSISTENT: "IT",
  COFORGE: "IT",
  HDFCBANK: "Financials",
  ICICIBANK: "Financials",
  SBIN: "Financials",
  KOTAKBANK: "Financials",
  AXISBANK: "Financials",
  BAJFINANCE: "Financials",
  BAJAJFINSV: "Financials",
  HDFCLIFE: "Financials",
  SBILIFE: "Financials",
  PFC: "Financials",
  RECLTD: "Financials",
  CHOLAFIN: "Financials",
  MUTHOOTFIN: "Financials",
  PAISALO: "Financials",
  PRUDENT: "Financials",
  BHARTIARTL: "Telecom",
  IDEA: "Telecom",
  TATAMOTORS: "Auto",
  M_M: "Auto",
  "M&M": "Auto",
  MARUTI: "Auto",
  BAJAJ_AUTO: "Auto",
  HEROMOTOCO: "Auto",
  EICHERMOT: "Auto",
  TVSMOTOR: "Auto",
  MOTHERSON: "Auto",
  PRICOLLTD: "Auto",
  SUNPHARMA: "Healthcare",
  DRREDDY: "Healthcare",
  CIPLA: "Healthcare",
  DIVISLAB: "Healthcare",
  APOLLOHOSP: "Healthcare",
  MAXHEALTH: "Healthcare",
  HINDUNILVR: "FMCG",
  ITC: "FMCG",
  NESTLEIND: "FMCG",
  BRITANNIA: "FMCG",
  TATACONSUM: "FMCG",
  DABUR: "FMCG",
  MARICO: "FMCG",
  TCS: "IT",
  LT: "Industrials",
  BEL: "Industrials",
  SIEMENS: "Industrials",
  HAL: "Industrials",
  TATASTEEL: "Materials",
  HINDALCO: "Materials",
  JSWSTEEL: "Materials",
  VEDL: "Materials",
  ULTRACEMCO: "Materials",
  SHREECEM: "Materials",
  ASIANPAINT: "Materials",
  ONGC: "Energy",
  NTPC: "Energy",
  POWERGRID: "Energy",
  COALINDIA: "Energy",
  ADANIENT: "Industrials",
  ADANIPORTS: "Industrials",
  ADANIGREEN: "Energy",
  ADANIPOWER: "Energy",
  DLF: "Realty",
  GODREJPROP: "Realty",
  PRESTIGE: "Realty",
  IRCTC: "Consumer",
  ZOMATO: "Consumer",
  ETERNAL: "Consumer",
  NYKAA: "Consumer",
  TRENT: "Consumer",
  DMART: "Consumer",
  TITAN: "Consumer",
  PRIVISCL: "Chemicals",
  SRF: "Chemicals",
  PIDILITIND: "Chemicals",
  DEEPAKNTR: "Chemicals",
  PIIND: "Chemicals",
};

export function baseSym(s) {
  return String(s || "")
    .toUpperCase()
    .replace(/\.(NS|BO)$/, "")
    .replace(/-/g, "_");
}

export const SECTOR_BENCH = {
  Financials: { symbol: "^NSEBANK", name: "Nifty Bank" },
  IT: { symbol: "^CNXIT", name: "Nifty IT" },
  Healthcare: { symbol: "^CNXPHARMA", name: "Nifty Pharma" },
  Auto: { symbol: "AUTOBEES.NS", name: "Auto BeES" },
  FMCG: { symbol: "CONSUMBEES.NS", name: "Consumption BeES" },
  Consumer: { symbol: "CONSUMBEES.NS", name: "Consumption BeES" },
  Energy: { symbol: "CPSEETF.NS", name: "CPSE ETF" },
  Telecom: { symbol: "^NSEI", name: "Nifty 50" },
  Materials: { symbol: "^CRSLDX", name: "Nifty 500" },
  Chemicals: { symbol: "^CRSLDX", name: "Nifty 500" },
  Industrials: { symbol: "^CRSLDX", name: "Nifty 500" },
  Realty: { symbol: "^CRSLDX", name: "Nifty 500" },
  Other: { symbol: "^NSEI", name: "Nifty 50" },
};

export const LARGE_CAP = new Set([
  "RELIANCE","TCS","HDFCBANK","BHARTIARTL","ICICIBANK","SBIN","INFY","LICI","ITC","HINDUNILVR",
  "LT","BAJFINANCE","HCLTECH","MARUTI","SUNPHARMA","KOTAKBANK","AXISBANK","ONGC","NTPC","TITAN",
  "ADANIENT","ADANIPORTS","POWERGRID","ULTRACEMCO","WIPRO","ASIANPAINT","BAJAJFINSV","TATAMOTORS",
  "COALINDIA","NESTLEIND","JSWSTEEL","TATASTEEL","M_M","M&M","TECHM","HINDALCO","GRASIM","CIPLA",
  "DRREDDY","APOLLOHOSP","EICHERMOT","DIVISLAB","TATACONSUM","BAJAJ_AUTO","HEROMOTOCO","BEL",
  "TRENT","ADANIGREEN","ADANIPOWER","JIOFIN","ETERNAL","ZOMATO",
]);

export function capOf(symbol) {
  return LARGE_CAP.has(baseSym(symbol)) ? "Large" : "Mid / small";
}

export function holdingWindows(bars) {
  const p = pathFromBars(bars, []);
  return {
    w1: windowReturn(p.nav, 7).port,
    m1: windowReturn(p.nav, 31).port,
    m3: windowReturn(p.nav, 93).port,
    m6: windowReturn(p.nav, 186).port,
    y1: windowReturn(p.nav, 365).port,
    ytd: ytdReturn(p.nav).port,
    cagr: mixCagr(p.nav),
    sessions: p.nav.length,
  };
}

export function sectorSleeve(rows, histories) {
  const groups = {};
  for (const r of rows) {
    const s = r.sector || "Other";
    groups[s] = groups[s] || { sector: s, rows: [], value: 0 };
    groups[s].rows.push(r);
    groups[s].value += r.value;
  }
  return Object.values(groups).map((g) => {
    const sleeve = buildMixPath(
      g.rows.map((r) => ({ symbol: r.symbol, qty: r.qty })),
      Object.fromEntries(g.rows.map((r) => [r.symbol, histories[r.symbol] || []])),
      [],
    );
    return {
      sector: g.sector,
      value: g.value,
      names: g.rows.length,
      symbols: g.rows.map((r) => r.symbol),
      windows: {
        m1: windowReturn(sleeve.nav, 31).port,
        m3: windowReturn(sleeve.nav, 93).port,
        y1: windowReturn(sleeve.nav, 365).port,
        ytd: ytdReturn(sleeve.nav).port,
        cagr: mixCagr(sleeve.nav),
      },
      bench: SECTOR_BENCH[g.sector] || SECTOR_BENCH.Other,
    };
  }).sort((a, b) => b.value - a.value);
}

export function sectorOf(symbol, yahooSector) {
  const b = baseSym(symbol);
  if (SECTORS[b]) return SECTORS[b];
  const raw = String(yahooSector || "").toLowerCase();
  if (!raw) return "Other";
  if (/(bank|nbfc|finance|insurance|capital market|financial)/.test(raw)) return "Financials";
  if (/(it |software|tech|computer|information)/.test(raw)) return "IT";
  if (/(oil|gas|energy|power|utility)/.test(raw)) return "Energy";
  if (/(pharma|health|drug|hospital|biotech)/.test(raw)) return "Healthcare";
  if (/(auto|motor|tyre|vehicle)/.test(raw)) return "Auto";
  if (/(fmcg|consumer staple|food|beverage|tobacco)/.test(raw)) return "FMCG";
  if (/(consumer discret|retail|apparel|internet)/.test(raw)) return "Consumer";
  if (/(cement|steel|metal|mining|commodity)/.test(raw)) return "Materials";
  if (/(realty|real estate)/.test(raw)) return "Realty";
  if (/(telecom|communication)/.test(raw)) return "Telecom";
  if (/(chem|specialty)/.test(raw)) return "Chemicals";
  if (/(capital good|industrial|engineering|defence|defense)/.test(raw)) return "Industrials";
  return "Other";
}

export function insights(book) {
  const pts = [];
  const { holdings, risk, windows, coverage, missing } = book;
  const n = holdings.length;
  if (!n) return [{ title: "Empty", figure: "—", body: "Add names to see mix quality.", tone: "warn" }];

  const top = [...holdings].sort((a, b) => b.value - a.value)[0];
  if (top && top.weight > 0.18) {
    pts.push({
      title: "Concentration",
      figure: (top.weight * 100).toFixed(0) + "%",
      body: `${top.symbol} is the largest line. Top-name risk is real if the thesis breaks.`,
      tone: top.weight > 0.28 ? "bad" : "warn",
    });
  } else {
    pts.push({
      title: "Spread",
      figure: n + " names",
      body: "No single line dominates. Size is spread across the mix.",
      tone: "good",
    });
  }

  if (windows?.y1?.port != null && windows.y1.bench != null) {
    const gap = windows.y1.port - windows.y1.bench;
    pts.push({
      title: "Vs Nifty · 1Y",
      figure: (gap >= 0 ? "+" : "") + gap.toFixed(1) + " pp",
      body: gap >= 0 ? "Mix beat the index on this window." : "Mix lagged the index on this window.",
      tone: gap >= 0 ? "good" : "bad",
    });
  }

  if (risk.maxDd != null) {
    pts.push({
      title: "Max drawdown",
      figure: risk.maxDd.toFixed(1) + "%",
      body: "Peak-to-trough on the mix path. Dates not required.",
      tone: risk.maxDd < -25 ? "bad" : "warn",
    });
  }

  if (risk.downCap != null) {
    pts.push({
      title: "Down capture",
      figure: (risk.downCap * 100).toFixed(0) + "%",
      body: risk.downCap < 1 ? "Fell less than the index on down days." : "Fell more than the index on down days.",
      tone: risk.downCap < 1 ? "good" : "bad",
    });
  }

  const off = holdings.filter((h) => h.offHigh != null && h.offHigh <= -20).length;
  if (off) {
    pts.push({
      title: "Off highs",
      figure: off + " names",
      body: "≥20% below 52-week high. Check thesis, don’t average blindly.",
      tone: "warn",
    });
  }

  if (missing?.length) {
    pts.push({
      title: "Chart coverage",
      figure: coverage,
      body: "No Yahoo series for " + missing.join(", ") + ". Path uses the rest.",
      tone: "warn",
    });
  }

  const winners = holdings.filter((h) => h.unrealPct > 0).length;
  const losers = holdings.filter((h) => h.unrealPct < 0).length;
  pts.push({
    title: "Winners / losers",
    figure: winners + " / " + losers,
    body: "Unrealized vs average price on current quantity.",
    tone: winners >= losers ? "good" : "warn",
  });

  return pts.slice(0, 8);
}
