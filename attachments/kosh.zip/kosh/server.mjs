import http from "http";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { spawnSync } from "child_process";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(__dirname, "public");
const PORT = Number(process.env.PORT || 8787);
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const qCache = new Map();
const hCache = new Map();
const Q_TTL = 30_000;
const H_TTL = 60 * 60 * 1000;

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
};

function send(res, code, body, type = "application/json; charset=utf-8") {
  const buf = typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(code, { "Content-Type": type, "Cache-Control": "no-store" });
  res.end(buf);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

async function yahoo(url) {
  const res = await fetch(url, { headers: { "User-Agent": UA, Accept: "application/json" } });
  if (!res.ok) throw new Error(`Yahoo ${res.status}`);
  return res.json();
}

function chartUrl(symbol, range = "2y", interval = "1d") {
  return `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${interval}&range=${range}&includePrePost=false`;
}

function parseChart(data) {
  const r = data?.chart?.result?.[0];
  if (!r) return null;
  const m = r.meta || {};
  const ts = r.timestamp || [];
  const close = r.indicators?.quote?.[0]?.close || [];
  const adj = r.indicators?.adjclose?.[0]?.adjclose || [];
  const bars = [];
  for (let i = 0; i < ts.length; i++) {
    const a = adj[i];
    const c = close[i];
    const px = a != null && a > 0 ? Number(a) : c != null && c > 0 ? Number(c) : null;
    if (px != null) bars.push({ t: ts[i], c: px, raw: c != null && c > 0 ? Number(c) : px });
  }
  return {
    symbol: m.symbol,
    name: m.longName || m.shortName || m.symbol,
    shortName: m.shortName || m.symbol,
    price: Number(m.regularMarketPrice || 0),
    previousClose: Number(m.chartPreviousClose || m.previousClose || 0),
    changePct: Number(m.regularMarketChangePercent || 0),
    high52: Number(m.fiftyTwoWeekHigh || 0),
    low52: Number(m.fiftyTwoWeekLow || 0),
    currency: m.currency || "INR",
    exchange: m.exchangeName || "",
    first: bars[0]?.t || null,
    last: bars.at(-1)?.t || null,
    sessions: bars.length,
    bars,
  };
}

async function fetchChart(symbol, range = "10y") {
  const key = `${symbol}|${range}`;
  const hit = hCache.get(key);
  if (hit && Date.now() - hit.at < H_TTL) return hit.data;
  const data = parseChart(await yahoo(chartUrl(symbol, range)));
  if (!data) throw new Error("no chart");
  hCache.set(key, { at: Date.now(), data });
  return data;
}

function suffixTries(raw) {
  const s = String(raw || "").trim().toUpperCase();
  if (!s) return [];
  if (s.startsWith("^") || s.includes("=")) return [s];
  if (/\.(NS|BO)$/.test(s)) return [s];
  return [s + ".NS", s + ".BO", s];
}

async function resolveSymbol(raw) {
  for (const y of suffixTries(raw)) {
    try {
      const d = await fetchChart(y, "1mo");
      if (d && d.bars.length >= 3 && d.price > 0) return d;
    } catch {
      /* next */
    }
  }
  return null;
}

async function handleQuote(url, res) {
  const symbols = String(url.searchParams.get("symbols") || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 40);
  const quotes = await Promise.all(
    symbols.map(async (s) => {
      const ck = "q:" + s.toUpperCase();
      const cached = qCache.get(ck);
      if (cached && Date.now() - cached.at < Q_TTL) return cached.data;
      const d = await resolveSymbol(s);
      const out = d
        ? {
            input: s,
            symbol: d.symbol,
            name: d.name,
            price: d.price,
            previousClose: d.previousClose,
            changePct: d.changePct,
            high52: d.high52,
            low52: d.low52,
            exchange: d.exchange,
            currency: d.currency,
          }
        : { input: s, symbol: s, name: s, price: 0, error: "unresolved" };
      qCache.set(ck, { at: Date.now(), data: out });
      return out;
    }),
  );
  send(res, 200, { quotes });
}

async function searchYahoo(q) {
  try {
    const data = await yahoo(
      `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&quotesCount=8&newsCount=0`,
    );
    return (data.quotes || []).filter((x) => x.quoteType === "EQUITY" || x.quoteType === "INDEX");
  } catch {
    return [];
  }
}

async function resolveHistory(symbol, range = "2y") {
  const tried = new Set();
  const order = suffixTries(symbol);
  for (const y of order) {
    tried.add(y);
    try {
      const got = await fetchChart(y, range);
      if (got?.bars?.length >= 5) return got;
    } catch {
      /* next */
    }
  }
  const hits = await searchYahoo(String(symbol).replace(/\.(NS|BO)$/i, ""));
  for (const h of hits) {
    if (!h.symbol || tried.has(h.symbol)) continue;
    if (!/\.(NS|BO)$/i.test(h.symbol) && !String(h.symbol).startsWith("^")) continue;
    try {
      const got = await fetchChart(h.symbol, range);
      if (got?.bars?.length >= 5) return got;
    } catch {
      /* next */
    }
  }
  return null;
}

async function handleHistory(url, res) {
  const symbol = String(url.searchParams.get("symbol") || "").trim();
  const range = String(url.searchParams.get("range") || "10y");
  if (!symbol) return send(res, 400, { error: "symbol required" });
  const d = await resolveHistory(symbol, range);
  if (!d) return send(res, 200, { symbol, bars: [], missing: true });
  send(res, 200, packHistory(symbol, d));
}

async function poolMap(items, limit, fn) {
  const out = new Array(items.length);
  let i = 0;
  async function worker() {
    while (i < items.length) {
      const idx = i++;
      out[idx] = await fn(items[idx]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return out;
}

async function handleHistories(req, res) {
  const body = JSON.parse((await readBody(req)).toString("utf8") || "{}");
  const symbols = [...new Set((body.symbols || []).map((s) => String(s).trim()).filter(Boolean))].slice(0, 80);
  const range = body.range || "10y";
  const rows = await poolMap(symbols, 6, async (s) => {
    const d = await resolveHistory(s, range);
    return d ? packHistory(s, d) : { input: s, symbol: s, bars: [], missing: true };
  });
  send(res, 200, { rows, range, asOf: new Date().toISOString() });
}

function packHistory(input, d) {
  return {
    input,
    symbol: d.symbol,
    name: d.name,
    price: d.price,
    previousClose: d.previousClose,
    changePct: d.changePct,
    high52: d.high52,
    low52: d.low52,
    first: d.first,
    last: d.last,
    sessions: d.sessions,
    bars: d.bars,
    missing: false,
  };
}

async function handleSearch(url, res) {
  const q = String(url.searchParams.get("q") || "").trim();
  if (!q) return send(res, 200, { quotes: [] });
  const data = await yahoo(
    `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(q)}&quotesCount=8&newsCount=0`,
  );
  const quotes = (data.quotes || [])
    .filter((x) => x.quoteType === "EQUITY" || x.quoteType === "INDEX")
    .map((x) => ({
      symbol: x.symbol,
      name: x.shortname || x.longname || x.symbol,
      exch: x.exchDisp || x.exchange,
    }));
  send(res, 200, { quotes });
}

async function handleTape(_url, res) {
  const idx = [
    { id: "nifty", symbol: "^NSEI", label: "NIFTY" },
    { id: "sensex", symbol: "^BSESN", label: "SENSEX" },
    { id: "bank", symbol: "^NSEBANK", label: "BANKNIFTY" },
    { id: "it", symbol: "^CNXIT", label: "NIFTY IT" },
    { id: "pharma", symbol: "^CNXPHARMA", label: "PHARMA" },
    { id: "mid", symbol: "^NSEMDCP50", label: "MIDCAP 50" },
  ];
  const rows = await Promise.all(
    idx.map(async (i) => {
      try {
        const d = await fetchChart(i.symbol, "5d");
        return { ...i, price: d.price, changePct: d.changePct };
      } catch {
        return { ...i, price: 0, changePct: 0 };
      }
    }),
  );
  send(res, 200, { rows, asOf: new Date().toISOString() });
}

function handleParse(body, res) {
  let payload;
  try {
    payload = JSON.parse(body.toString("utf8"));
  } catch {
    return send(res, 400, { error: "bad json" });
  }
  const { filename, base64 } = payload || {};
  if (!base64) return send(res, 400, { error: "file missing" });
  const raw = Buffer.from(String(base64).replace(/^data:.*,/, ""), "base64");
  const tmp = path.join("/tmp", "kosh-" + Date.now() + "-" + String(filename || "up").replace(/[^\w.-]/g, "_"));
  fs.writeFileSync(tmp, raw);
  try {
    const py = `
import json,sys,csv
from openpyxl import load_workbook
p=sys.argv[1]
rows=[]
if p.lower().endswith(('.xlsx','.xls')):
    wb=load_workbook(p, read_only=True, data_only=True)
    ws=wb.active
    data=list(ws.iter_rows(values_only=True))
    if not data:
        print(json.dumps([])); raise SystemExit
    hdr=[str(x or '').strip() for x in data[0]]
    for r in data[1:]:
        rows.append({hdr[i]: ('' if r[i] is None else r[i]) for i in range(min(len(hdr), len(r)))})
else:
    with open(p,'r',encoding='utf-8',errors='ignore') as f:
        sample=f.read(4096); f.seek(0)
        try:
            dialect=csv.Sniffer().sniff(sample, delimiters=',\\t;|')
        except Exception:
            dialect=csv.excel
        r=csv.DictReader(f, dialect=dialect)
        rows=[{k:v for k,v in row.items()} for row in r]
print(json.dumps(rows, default=str))
`;
    const out = spawnSync("python3", ["-c", py, tmp], { encoding: "utf8", maxBuffer: 20 * 1024 * 1024 });
    if (out.status !== 0) {
      return send(res, 400, { error: "Could not read file", detail: String(out.stderr || "").slice(0, 200) });
    }
    const rows = JSON.parse(out.stdout || "[]");
    send(res, 200, { filename: filename || "upload", rows: rows.length, holdings: extractHoldings(rows) });
  } finally {
    try { fs.unlinkSync(tmp); } catch { /* ignore */ }
  }
}

function normKey(k) {
  return String(k || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}
function pick(map, keys) {
  for (const k of keys) if (map[k] !== undefined && map[k] !== "") return map[k];
  return "";
}
function num(v) {
  if (v == null || v === "") return 0;
  const n = Number(String(v).replace(/[,₹]/g, ""));
  return Number.isFinite(n) ? n : 0;
}
function cleanSym(s) {
  return String(s).trim().toUpperCase().replace(/^(NSE:|BSE:|IND:)/, "").replace(/\s+/g, "");
}
function extractHoldings(rows) {
  const out = [];
  for (const row of rows) {
    const map = {};
    for (const [k, v] of Object.entries(row || {})) map[normKey(k)] = v;
    const symbol =
      pick(map, [
        "symbol","ticker","nscesymbol","scripcode","tradingsymbol","stock","scrip","isin","name","company","instrument",
      ]) || "";
    const qty = num(pick(map, ["qty","quantity","netqty","freeqty","holdingqty","shares","units"]));
    const avg = num(pick(map, ["avg","avgprice","averageprice","buyavg","buyprice","costprice","averagecost","netprice"]));
    const date = String(pick(map, ["date","buydate","tradedate","purchasedate","acquiredon"]) || "").slice(0, 12);
    if (!symbol || qty <= 0) continue;
    out.push({
      symbol: cleanSym(symbol),
      name: String(pick(map, ["companyname","company","securityname","name"]) || symbol),
      qty,
      avg: avg || null,
      date: date || null,
    });
  }
  const m = new Map();
  for (const r of out) {
    const cur = m.get(r.symbol);
    if (!cur) m.set(r.symbol, { ...r });
    else {
      const q = cur.qty + r.qty;
      const avg = cur.avg && r.avg ? (cur.avg * cur.qty + r.avg * r.qty) / q : cur.avg || r.avg;
      m.set(r.symbol, { ...cur, qty: q, avg, date: cur.date || r.date });
    }
  }
  return [...m.values()];
}

function serveStatic(urlPath, res) {
  let rel = decodeURIComponent(urlPath.split("?")[0]);
  if (rel === "/") rel = "/index.html";
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC)) return send(res, 403, "forbidden", "text/plain");
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    return send(res, 200, fs.readFileSync(path.join(PUBLIC, "index.html")), MIME[".html"]);
  }
  const ext = path.extname(file);
  send(res, 200, fs.readFileSync(file), MIME[ext] || "application/octet-stream");
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost");
    if (url.pathname === "/api/health") return send(res, 200, { ok: true, app: "kosh" });
    if (url.pathname === "/api/quote") return await handleQuote(url, res);
    if (url.pathname === "/api/history") return await handleHistory(url, res);
    if (url.pathname === "/api/histories" && req.method === "POST") return await handleHistories(req, res);
    if (url.pathname === "/api/search") return await handleSearch(url, res);
    if (url.pathname === "/api/tape") return await handleTape(url, res);
    if (url.pathname === "/api/parse-holdings" && req.method === "POST") {
      return handleParse(await readBody(req), res);
    }
    return serveStatic(url.pathname, res);
  } catch (e) {
    send(res, 502, { error: String(e.message || e) });
  }
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Kosh on http://localhost:${PORT}`);
});
