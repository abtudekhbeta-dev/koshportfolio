# Kosh

Indian stock portfolio tracker. Live Yahoo prices. Mix path does not need buy dates.

## Run

```bash
node server.mjs
```

Open http://localhost:8787

No npm install. Node 18+ is enough. Python 3 + openpyxl is used only when you upload `.xlsx`.

## What this build fixes

The old join kept a date only if every holding printed that exact Unix second. One SME / BSE-only name wiped the chart and printed `0.0%` vol.

Now:

- Resolve each ticker as stored, then `.NS`, then `.BO`
- Union of IST calendar days, last close carried forward
- Chart chip shows `16/18 names · 248 sessions`
- Dead tickers are skipped, not fatal
- Sharpe / Sortino / vol print `—` when the series is too short, never `0.0%`
- Day P&L ignores a single-name move above 25%
- Sector from a local NSE map (Yahoo profile is crumb-locked)

## Use

1. Guest (no details) or username + password only
2. Sample · core is seeded for guest so charts load immediately
3. Add more portfolios. Upload multiple CSV/XLSX holdings files, type names, or speak them. Custom benchmark accepted.
4. Avg price and buy date are optional
5. Benchmark: Nifty 50, Sensex, Bank Nifty, Nifty IT
6. Chart modes: cumulative, rolling 1Y, monthly, drawdown
7. Compare two portfolios on mix 1Y and CAGR

XIRR still needs buy dates or a trade book. Mix CAGR and vs-index charts do not.
